//
//  Header.h
//  Leilao
//
//  Created by Ândriu Coelho on 22/05/18.
//  Copyright © 2018 Alura. All rights reserved.
//

#ifndef Header_h
#define Header_h

#import <sqlite3.h>


#endif /* Header_h */
